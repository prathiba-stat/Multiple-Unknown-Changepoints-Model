This project uses Infer.NET 2.5, assumed to be installed under c:\Program Files\Infer.NET 2.5.  You can get it at:
http://research.microsoft.com/infernet/

This project makes use of DocumentFormat.OpenXml to read Excel files.  To get it, you need to install the free Open XML SDK 2.5 for Office:
http://www.microsoft.com/en-gb/download/details.aspx?id=30425

