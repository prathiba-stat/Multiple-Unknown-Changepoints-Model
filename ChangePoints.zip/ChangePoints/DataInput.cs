﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Spreadsheet;

namespace ChangePoints
{
    public static class DataInput
    {
        /// <summary>
        /// Parse an Excel file into a mapping from worksheet -> column name -> list of values
        /// </summary>
        /// <param name="filename"></param>
        /// <returns></returns>
        public static Dictionary<string, Dictionary<string, List<string>>> ReadExcelFile(string filename)
        {
            Dictionary<string, Dictionary<string, List<string>>> result = new Dictionary<string, Dictionary<string, List<string>>>();
            using (SpreadsheetDocument myDoc = SpreadsheetDocument.Open(filename, false))
            {
                SharedStringTable ssTable = myDoc.WorkbookPart.SharedStringTablePart.SharedStringTable;
                foreach (var worksheetPart in myDoc.WorkbookPart.WorksheetParts)
                {
                    var worksheet = worksheetPart.Worksheet;
                    string sheetName = GetSheetName(myDoc, worksheet);
                    Dictionary<string, List<string>> columnData = new Dictionary<string, List<string>>();
                    SheetData sheetData = worksheet.GetFirstChild<SheetData>();
                    Dictionary<string, string> columnKey = new Dictionary<string, string>();
                    uint prevRowIndex = 0;
                    foreach (Row r in sheetData.Elements<Row>())
                    {
                        uint rowIndex = r.RowIndex.Value;
                        bool firstRow = (rowIndex == 1);
                        if (firstRow)
                        {
                            foreach (Cell cell in r.Elements<Cell>())
                            {
                                string name = GetColumnName(cell);
                                string key = GetCellText(cell, ssTable);
                                columnKey[name] = key;
                                columnData[key] = new List<string>();
                            }
                            firstRow = false;
                        }
                        else if (prevRowIndex != rowIndex - 1)
                        {
                            // stop if there is a gap in the sheet
                            break;
                        }
                        else
                        {
                            foreach (Cell cell in r.Elements<Cell>())
                            {
                                string key;
                                if (columnKey.TryGetValue(GetColumnName(cell), out key))
                                {
                                    if (columnData.ContainsKey(key))
                                    {
                                        string text = GetCellText(cell, ssTable);
                                        if (text != null && text.Length > 0)
                                        {
                                            columnData[key].Add(text);
                                        }
                                    }
                                }
                            }
                        }
                        prevRowIndex = rowIndex;
                    }
                    result[sheetName] = columnData;
                }
            }
            return result;
        }

        public static string GetCellText(Cell cell, SharedStringTable ssTable)
        {
            if (cell.DataType != null && cell.DataType == CellValues.SharedString)
                return ssTable.ChildElements[Convert.ToInt32(cell.CellValue.Text)].InnerText;
            else if (cell.CellValue != null)
                return cell.CellValue.Text;
            else
                return null;
        }

        public static string GetSheetName(SpreadsheetDocument doc, Worksheet worksheet)
        {
            string id = doc.WorkbookPart.GetIdOfPart(worksheet.WorksheetPart);
            foreach (Sheet sheet in doc.WorkbookPart.Workbook.Sheets)
            {
                if (sheet.Id == id)
                    return sheet.Name;
            }
            return null;
        }

        public static string GetColumnName(Cell cell)
        {
            string s = cell.CellReference.Value;
            return GetColumnName(s);
        }

        // Source: http://stackoverflow.com/questions/3837981/reading-excel-open-xml-is-ignoring-blank-cells
        /// <summary>
        /// Given a cell name, return the cell column name.
        /// </summary>
        /// <param name="cellReference">Address of the cell (ie. B2)</param>
        /// <returns>Column Name (ie. B)</returns>
        /// <exception cref="ArgumentOutOfRangeException">cellReference</exception>
        public static string GetColumnName(string cellReference)
        {
            // Advance from L to R until a number, then return 0 through previous position
            for (int lastCharPos = 0; lastCharPos < cellReference.Length; lastCharPos++)
                if (Char.IsNumber(cellReference[lastCharPos]))
                    return cellReference.Substring(0, lastCharPos);

            throw new ArgumentOutOfRangeException("cellReference");
        }

        public static Dictionary<string, List<string>> ReadCsv(string path)
        {
            Dictionary<string, List<string>> result = new Dictionary<string, List<string>>();
            using (var reader = new StreamReader(path))
            {
                string header = reader.ReadLine();
                string[] columnNames = header.Split(',');
                foreach (var columnName in columnNames)
                {
                    result[columnName] = new List<string>();
                }
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] values = line.Split(',');
                    for (int i = 0; i < values.Length; i++)
                    {
                        var list = result[columnNames[i]];
                        list.Add(values[i]);
                    }
                }
            }
            return result;
        }

    }
}
