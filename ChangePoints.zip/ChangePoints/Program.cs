﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MicrosoftResearch.Infer.Models;
using MicrosoftResearch.Infer;
using MicrosoftResearch.Infer.Collections;
using MicrosoftResearch.Infer.Distributions;
using MicrosoftResearch.Infer.Utils;
using MicrosoftResearch.Infer.Maths;
using System.Diagnostics;

namespace ChangePoints
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            //var dict = DataInput.ReadCsv(@"..\..\..\Neely.csv");
            //string name = "CB-Dan";
            //var strings = dict[name];
            //var phaseStrings = dict["Phase-" + name];

            var xls = DataInput.ReadExcelFile(@"..\..\..\ABAB-data.xlsx");
            //string sheet = "Lin 2014";
            //string name = "Helen";
            string sheet = "Neely 2013";
            string name = "CB-Dan";
            List<string> phaseStrings;
            if (sheet == "Neely 2013" || sheet == "Shih 2015")
                phaseStrings = xls[sheet]["Phase-" + name];
            else
                phaseStrings = xls[sheet]["Phase"];
            var strings = xls[sheet][name];
            bool inertia = false;

            double[] data = Util.ArrayInit(strings.Count, i => (strings[i].Length == 0) ? -1.0 : double.Parse(strings[i]));
            bool[] notMissing = Util.ArrayInit(strings.Count, i => (strings[i].Length > 0));
            // determine the true changepoints
            var truePhases = Util.ArrayInit(phaseStrings.Count, i => (phaseStrings[i].Length==0) ? -1 : int.Parse(phaseStrings[i]));
            int numPhases = 4;
            var phaseStarts = new int[numPhases];
            for (int phase = 0; phase < numPhases; phase++)
            {
                int index = truePhases.IndexOf(phase + 1);
                phaseStarts[phase] = index;
            }
            RunInferenceUnrolled(@"..\..\"+name+"-results.csv", data, notMissing, inertia, phaseStarts);
            //RunInference(data, notMissing, false, phaseStarts);
            Console.ReadKey();
        }

        public static Variable<double> StationaryNoise(Variable<double> noisePrecision, Variable<double> rho)
        {
            // rho^2 * steady + v = steady
            // steady = v/(1 - rho^2) = v*(1 + rho^2 + rho^4 + ...)
            Variable<double> noise = Variable.GaussianFromMeanAndPrecision(0, noisePrecision);
            for (int i = 0; i < 2; i++)
            {
                var noise2 = Variable.GaussianFromMeanAndPrecision(rho * noise, noisePrecision);
                // this is needed to work around a bug in Infer.NET
                noise2.InitialiseTo(Gaussian.PointMass(0));
                noise = noise2;
            }
            return noise;
        }

        /// <summary>
        /// Perform inference in unrolled model
        /// </summary>
        /// <param name="data"></param>
        /// <param name="notMissing"></param>
        /// <param name="inertia"></param>
        /// <param name="phaseStarts"></param>
        public static void RunInferenceUnrolled(string outputPath, double[] data, bool[] notMissing, bool inertia, int[] phaseStarts)
        {
            int timesteps = data.Length;
            int numPhases = phaseStarts.Length;
            Range phase = new Range(numPhases).Named("phase");
            Variable<double>[] observations = new Variable<double>[timesteps];

            var phase1Start = Variable.Observed(0).Named("phase1Start");
            var phase2Start = Variable.Observed(1).Named("phase2Start");
            var phase3Start = Variable.Observed(2).Named("phase3Start");

            var evidence = Variable.Bernoulli(0.5).Named("evidence");
            IfBlock evBlock = null;
            evBlock = Variable.If(evidence);

            var intercept = Variable.Array<double>(phase).Named("intercept");
            intercept[phase] = Variable.GaussianFromMeanAndPrecision(0, 1e-4).ForEach(phase);
            Variable<int>[] phaseAtTime = new Variable<int>[timesteps];
            var noisePrecision = Variable.GammaFromMeanAndVariance(1, 1).Named("noisePrecision");
            var rho = Variable.GaussianFromMeanAndPrecision(0, 1).Named("rho");
            // Uncomment this to remove autocorrelation
            //rho.ObservedValue = 0;  

            for (int t = 0; t < timesteps; t++)
            {
                phaseAtTime[t] = Variable.New<int>().Named("phaseAtTime" + t);
                phaseAtTime[t].SetValueRange(phase);
                phaseAtTime[t].AddAttribute(new MarginalPrototype(Discrete.Uniform(numPhases)));
                var phase0 = (t < phase1Start).Named("phase0_" + t);
                using (Variable.If(phase0))
                {
                    phaseAtTime[t].SetTo(0);
                }
                using (Variable.IfNot(phase0))
                {
                    var phase1 = (t < phase2Start).Named("phase1_" + t);
                    using (Variable.If(phase1))
                    {
                        phaseAtTime[t].SetTo(1);
                    }
                    using (Variable.IfNot(phase1))
                    {
                        var phase2 = (t < phase3Start).Named("phase2_" + t);
                        using (Variable.If(phase2))
                        {
                            phaseAtTime[t].SetTo(2);
                        }
                        using (Variable.IfNot(phase2))
                        {
                            phaseAtTime[t].SetTo(3);
                        }
                    }
                }
                if (t == 0)
                {
                    var prevNoise = StationaryNoise(noisePrecision, rho).Named("statNoise" + t);
                    using (Variable.Switch(phaseAtTime[t]))
                        observations[t] = Variable.GaussianFromMeanAndPrecision(rho * prevNoise + intercept[phaseAtTime[t]], noisePrecision);
                }
                else if(inertia)
                {
                    observations[t] = Variable.New<double>();
                    Variable<double> prevNoise = Variable.New<double>().Named("prevNoise" + t);
                    using (Variable.Switch(phaseAtTime[t - 1]))
                    {
                        prevNoise.SetTo(observations[t - 1] - intercept[phaseAtTime[t - 1]]);
                    }
                    using (Variable.Switch(phaseAtTime[t]))
                        observations[t].SetTo(Variable.GaussianFromMeanAndPrecision(rho * prevNoise + intercept[phaseAtTime[t]], noisePrecision));
                } 
                else {
                    observations[t] = Variable.New<double>();
                    var phaseChanged = (phaseAtTime[t] != phaseAtTime[t - 1]).Named("phaseChanged" + t);
                    using (Variable.If(phaseChanged))
                    {
                        var prevNoise = StationaryNoise(noisePrecision, rho).Named("statNoise" + t);
                        using (Variable.Switch(phaseAtTime[t]))
                            observations[t].SetTo(Variable.GaussianFromMeanAndPrecision(rho * prevNoise + intercept[phaseAtTime[t]], noisePrecision));
                    }
                    using (Variable.IfNot(phaseChanged))
                    {
                        Variable<double> prevNoise = Variable.New<double>().Named("prevNoise" + t);
                        using (Variable.Switch(phaseAtTime[t - 1]))
                        {
                            prevNoise.SetTo(observations[t - 1] - intercept[phaseAtTime[t - 1]]);
                        }
                        using (Variable.Switch(phaseAtTime[t]))
                            observations[t].SetTo(Variable.GaussianFromMeanAndPrecision(rho * prevNoise + intercept[phaseAtTime[t]], noisePrecision));
                    }
                }
                observations[t].Name = "observation" + t;
                if(notMissing[t])
                    observations[t].ObservedValue = data[t];
            }
            if (evBlock != null) evBlock.CloseBlock();

            InferenceEngine engine = new InferenceEngine();
            engine.Algorithm = new VariationalMessagePassing();
            engine.Compiler.RecommendedQuality = QualityBand.Experimental;
            engine.OptimiseForVariables = new IVariable[] { evidence, rho, noisePrecision, intercept };
            engine.Compiler.AddComments = false;
            engine.ShowProgress = false;
            engine.Compiler.ShowProgress = true;

            Stopwatch watch = new Stopwatch();
            watch.Start();
            List<double> logProbs = new List<double>();
            List<Gaussian> rhos = new List<Gaussian>();
            List<Gamma> noises = new List<Gamma>();
            List<IList<Gaussian>> intercepts = new List<IList<Gaussian>>();
            bool verbose = false;
            for (int i = 0; i < timesteps - 2; i++)
            {
                //i = phaseStarts[1];
                phase1Start.ObservedValue = i;
                for (int j = i + 1; j < timesteps - 1; j++)
                {
                    //j = phaseStarts[2]-1;
                    phase2Start.ObservedValue = j;
                    for (int k = j + 1; k < timesteps; k++)
                    {
                        //k = phaseStarts[3];
                        phase3Start.ObservedValue = k;
                        Console.WriteLine("{0},{1},{2}", i, j, k);
                        double logProb = 0;
                        for (int iter = 1; iter < 100; iter++)
                        {
                            engine.NumberOfIterations = iter;
                            double logProb2 = engine.Infer<Bernoulli>(evidence).LogOdds;
                            if (verbose) Console.WriteLine("logProb = {0}", logProb2);
                            if (!double.IsInfinity(logProb2) && MMath.AbsDiff(logProb, logProb2, 1e-10) < 1e-4) break;
                            logProb = logProb2;
                        }
                        logProbs.Add(logProb);
                        var rhoActual = engine.Infer<Gaussian>(rho);
                        rhos.Add(rhoActual);
                        var noiseActual = engine.Infer<Gamma>(noisePrecision);
                        noises.Add(noiseActual);
                        var interceptActual = engine.Infer<IList<Gaussian>>(intercept);
                        intercepts.Add(interceptActual);
                        if (verbose)
                        {
                            Console.WriteLine(StringUtil.JoinColumns("intercept = ", interceptActual));
                            Console.WriteLine("rho = {0}", rhoActual);
                            Console.WriteLine("noisePrecision = {0}", noiseActual);
                        }
                    }
                }
            }
            watch.Stop();
            Console.WriteLine("took {0}s", watch.ElapsedMilliseconds/1000);
            if (evBlock == null) return;

            Vector probs = Vector.FromList(logProbs);
            double max = probs.Max();
            probs.SetToDifference(probs, max);
            probs.SetToFunction(probs, Math.Exp);
            double sum = probs.Sum();
            probs.Scale(1.0 / sum);
            using (var writer = new System.IO.StreamWriter(outputPath))
            {
                writer.Write("phase1Start,phase2Start,phase3Start,probability,logProb,rho,rhoSE,noisePrecision");
                for (int s = 0; s < numPhases; s++)
                {
                    writer.Write(",intercept{0},intercept{0}SE", s);
                }
                writer.WriteLine();
                int count = 0;
                for (int i = 0; i < timesteps - 2; i++)
                {
                    for (int j = i + 1; j < timesteps - 1; j++)
                    {
                        for (int k = j + 1; k < timesteps; k++)
                        {
                            if (probs[count] > 1e-4)
                            {
                                Gaussian rhoDist = rhos[count];
                                double rhoSE = Math.Sqrt(rhoDist.GetVariance());
                                Gamma noiseDist = noises[count];
                                IList<Gaussian> interceptDist = intercepts[count];
                                writer.Write("{0},{1},{2},{3},{4},{5},{6},{7}", i, j, k, probs[count].ToString("g4"), logProbs[count].ToString("g4"),
                                    rhoDist.GetMean().ToString("g4"), rhoSE.ToString("g4"), noiseDist.GetMean().ToString("g4"));
                                for (int s = 0; s < numPhases; s++)
                                {
                                    Gaussian dist = interceptDist[s];
                                    double se = Math.Sqrt(dist.GetVariance());
                                    writer.Write(",{0},{1}", dist.GetMean().ToString("g4"), se.ToString("g4"));
                                }
                                writer.WriteLine();
                            }
                            count++;
                        }
                    }
                }
            }
        }        

        /// <summary>
        /// This version compiles faster but runs slower
        /// </summary>
        /// <param name="data"></param>
        /// <param name="notMissing"></param>
        /// <param name="inertia"></param>
        /// <param name="phaseStarts"></param>
        public static void RunInference(double[] data, bool[] notMissing, bool inertia, int[] phaseStarts)
        {
            int timesteps = data.Length;
            int numPhases = phaseStarts.Length;
            Range time = new Range(timesteps).Named("time");
            Range phase = new Range(numPhases).Named("phase");
            var isObserved = Variable.Array<bool>(time).Named("isObserved");
            isObserved.ObservedValue = notMissing;
            var observation = Variable.Array<double>(time).Named("observation");
            observation.ObservedValue = data;

            var phase1Start = Variable.Observed(0).Named("phase1Start");
            var phase2Start = Variable.Observed(1).Named("phase2Start");
            var phase3Start = Variable.Observed(2).Named("phase3Start");

            var evidence = Variable.Bernoulli(0.5).Named("evidence");
            IfBlock evBlock = null;
            evBlock = Variable.If(evidence);

            var intercept = Variable.Array<double>(phase).Named("intercept");
            intercept[phase] = Variable.GaussianFromMeanAndPrecision(0, 1e-4).ForEach(phase);
            var phaseAtTime = Variable.Array<int>(time).Named("phaseAtTime");
            phaseAtTime.SetValueRange(phase);
            phaseAtTime.AddAttribute(new MarginalPrototype(Discrete.Uniform(numPhases)));
            var noisePrecision = Variable.GammaFromMeanAndVariance(1, 1).Named("noisePrecision");
            var noiseAtTime = Variable.Array<double>(time).Named("noiseAtTime");
            var rho = Variable.GaussianFromMeanAndPrecision(0, 1).Named("rho");
            //rho.ObservedValue = 0;  

            using (var block = Variable.ForEach(time))
            {
                var t = block.Index;
                var phase0 = (t < phase1Start).Named("phase0");
                using (Variable.If(phase0))
                {
                    phaseAtTime[t] = 0;
                }
                using (Variable.IfNot(phase0))
                {
                    var phase1 = (t < phase2Start).Named("phase1");
                    using (Variable.If(phase1))
                    {
                        phaseAtTime[t] = 1;
                    }
                    using (Variable.IfNot(phase1))
                    {
                        var phase2 = (t < phase3Start).Named("phase2");
                        using (Variable.If(phase2))
                        {
                            phaseAtTime[t] = 2;
                        }
                        using (Variable.IfNot(phase2))
                        {
                            phaseAtTime[t] = 3;
                        }
                    }
                }
                using (Variable.If(t == 0))
                {
                    noiseAtTime[t] = StationaryNoise(noisePrecision, rho);
                }
                using (Variable.If(t > 0))
                {
                    var phaseChanged = (phaseAtTime[t] != phaseAtTime[t - 1]);
                    if (!inertia)
                    {
                        using (Variable.If(phaseChanged))
                        {
                            noiseAtTime[t] = StationaryNoise(noisePrecision, rho);
                        }
                        using (Variable.IfNot(phaseChanged))
                        {
                            noiseAtTime[t] = Variable.GaussianFromMeanAndPrecision(rho * noiseAtTime[t - 1], noisePrecision);
                        }
                    }
                    else
                    {
                        var prevError = noiseAtTime[t - 1] + intercept[phaseAtTime[t - 1]] - intercept[phaseAtTime[t]];
                        noiseAtTime[t] = Variable.GaussianFromMeanAndPrecision(rho * prevError, noisePrecision);
                    }
                }
                using (Variable.If(isObserved[t]))
                {
                    using (Variable.Switch(phaseAtTime[t]))
                        observation[t] = intercept[phaseAtTime[t]] + noiseAtTime[t];
                }
            }
            if(evBlock != null) evBlock.CloseBlock();

            InferenceEngine engine = new InferenceEngine();
            engine.Compiler.RecommendedQuality = QualityBand.Experimental;
            engine.Compiler.UseSerialSchedules = false;
            engine.ResetOnObservedValueChanged = false;

            List<double> logProbs = new List<double>();
            List<Gaussian> rhos = new List<Gaussian>();
            List<Gamma> noises = new List<Gamma>();
            for (int i = 0; i < timesteps-2; i++)
            {
                i = phaseStarts[1];
                phase1Start.ObservedValue = i;
                for (int j = i+1; j < timesteps-1; j++)
                {
                    j = phaseStarts[2];
                    phase2Start.ObservedValue = j;
                    for (int k = j+1; k < timesteps; k++)
                    {
                        k = phaseStarts[3];
                        phase3Start.ObservedValue = k;
                        Console.WriteLine("{0},{1},{2}", i, j, k);
                        double logProb = 0;
                        for (int iter = 1; iter < 100; iter++)
                        {
                            engine.NumberOfIterations = iter;
                            double logProb2 = engine.Infer<Bernoulli>(evidence).LogOdds;
                            Console.WriteLine("logProb = {0}", logProb2);
                            if (!double.IsInfinity(logProb2) && MMath.AbsDiff(logProb, logProb2, 1e-10) < 1e-4) break;
                            logProb = logProb2;
                        }
                        logProbs.Add(logProb);
                        Console.WriteLine("intercept:");
                        Console.WriteLine(engine.Infer(intercept));
                        var rhoActual = engine.Infer<Gaussian>(rho);
                        Console.WriteLine("rho = {0}", rhoActual);
                        rhos.Add(rhoActual);
                        var noiseActual = engine.Infer<Gamma>(noisePrecision);
                        Console.WriteLine("noisePrecision = {0}", noiseActual);
                        noises.Add(noiseActual);
                        break;
                    }
                    break;
                }
                break;
            }
            return;
            if (evBlock == null) return;

            Vector probs = Vector.FromList(logProbs);
            double max = probs.Max();
            probs.SetToDifference(probs, max);
            probs.SetToFunction(probs, Math.Exp);
            double sum = probs.Sum();
            probs.Scale(1.0/sum);
            using (var writer = new System.IO.StreamWriter("results.csv"))
            {
                writer.WriteLine("phase1Start,phase2Start,phase3Start,probability,logProb,rho,noisePrecision");
                int count = 0;
                for (int i = 0; i < timesteps - 2; i++)
                {
                    for (int j = i + 1; j < timesteps - 1; j++)
                    {
                        for (int k = j + 1; k < timesteps; k++)
                        {
                            Gaussian rhoDist = rhos[count];
                            Gamma noiseDist = noises[count];
                            writer.WriteLine("{0},{1},{2},{3},{4},{5},{6}", i, j, k, probs[count].ToString("g4"), logProbs[count].ToString("g4"),
                                rhoDist.GetMean().ToString("g4"), noiseDist.GetMean().ToString("g4"));
                            count++;
                        }
                    }
                }
            }
        }
    }
}
